let carY;

function setup() {

  createCanvas(800, 600);

  carY = 500;

}

function draw() {

  background(110, 220, 255);

  // Chão

  fill(100, 200, 100);

  rect(0, 400, width, 200);

  drawRural();

  drawCity();

  drawRoad();

  // Movimento do carro

  if (keyIsDown(UP_ARROW)) carY -= 3;

  if (keyIsDown(DOWN_ARROW)) carY += 3;

  carY = constrain(carY, 400, 500);

  drawCar(carY);

  // Apenas 1 animal (vaca)

  drawCow(150, 510);

}

function drawRural() {

  // Casa

  fill(200, 100, 50);

  rect(100, 430, 100, 70);

  fill(150, 50, 10);

  triangle(100, 430, 150, 390, 200, 430);

  // Árvore (sem conflito)

  fill(34, 139, 34);

  ellipse(40, 380, 80, 80);

  fill(139, 60, 19);

  rect(30, 410, 20, 40);

}

function drawCity() {

  noStroke();

  fill(80);

  rect(600, 300, 50, 200);

  fill(120);

  rect(670, 350, 50, 150);

}

function drawRoad() {

  fill(60);

  rect(390, 400, 20, 200);

  fill(255);

  for (let y = 420; y < 600; y += 40) {

    rect(397, y, 6, 20);

  }

}

function drawCar(cary) {

  fill(255, 0, 0);

  rect(380, cary, 40, 20);

  fill(0);

  ellipse(385, cary + 20, 10, 10);

  ellipse(415, cary + 20, 10, 10);

}

function drawCow(x, y) {

  fill(255);

  rect(x, y, 40, 20, 5);

  fill(0);

  ellipse(x + 10, y + 10, 10, 10);

}